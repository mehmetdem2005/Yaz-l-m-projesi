# DeepSeek App Studio — Android APK Build

Bu proje **Capacitor 6** ile Next.js 16 uygulamasını Android WebView'e sarmalar ve APK üretir.

## 📋 Bilgiler

- **App ID**: `com.deepseekstudio.app`
- **App Name**: DeepSeek App Studio
- **Version**: 1.0.0
- **Orientation**: both
- **Min SDK**: 23 (Android 6.0 Marshmallow)
- **Target SDK**: 34 (Android 14)
- **Capacitor**: 6.x
- **Web build**: Next.js static export

## 🚀 Hızlı Başlangıç

### 1. Bağımlılıkları yükle

```bash
npm install
```

### 2. Web build al (static export)

```bash
npm run build:static
```

Bu, `out/` klasörüne static HTML/CSS/JS üretir.

### 3. Capacitor sync

```bash
npx cap sync android
```

Bu, `out/` içeriğini `android/app/src/main/assets/public/` altına kopyalar.

### 4. Android Studio'da aç

```bash
npx cap open android
```

### 5. Debug APK derle

```bash
npm run android:build
```

veya Android Studio'da **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

Çıktı: `android/app/build/outputs/apk/debug/app-debug.apk`

## 📱 Cihaza Yükleme

### ADB ile (USB debug)

```bash
adb install android/app/build/outputs/apk/debug/app-debug.apk
```

### Manuel

APK dosyasını telefona kopyala, dosya yöneticisinden aç ve "Yükle" de.

## 🔑 Release APK (İmzalı)

### Keystore oluştur

```bash
keytool -genkey -v -keystore release.keystore \
  -alias deepseek-studio \
  -keyalg RSA -keysize 2048 \
  -validity 10000
```

### `android/app/key.properties`

```
storeFile=../release.keystore
storePassword=ŞİFRENİZ
keyAlias=deepseek-studio
keyPassword=ŞİFRENİZ
```

### `android/app/build.gradle` release block

```gradle
android {
    signingConfigs {
        release {
            storeFile file(System.getenv('HOME') + '/release.keystore')
            storePassword System.getenv('KEYSTORE_PASSWORD')
            keyAlias 'deepseek-studio'
            keyPassword System.getenv('KEY_PASSWORD')
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }
    }
}
```

### Release derle

```bash
npm run android:release
```

Çıktı: `android/app/build/outputs/apk/release/app-release.apk`

## 📐 Dosya Yapısı

```
deepseek-app-studio-android/
├── capacitor.config.ts       # Capacitor ayarları
├── package.json              # npm scripts
├── README.md                 # Bu dosya
└── android/
    ├── build.gradle          # Proje-level Gradle
    ├── settings.gradle       # Modül ayarları
    ├── gradle.properties     # Gradle ayarları
    └── app/
        ├── build.gradle      # App-level Gradle
        └── src/main/
            ├── AndroidManifest.xml
            ├── java/com/deepseekstudio/app/
            │   └── MainActivity.java
            └── res/
                ├── drawable/splash.xml
                └── values/
                    ├── strings.xml
                    ├── styles.xml
                    └── colors.xml
```

## 🎨 Özelleştirme

### App ID değiştir

`capacitor.config.ts` içindeki `appId` ve `android/app/build.gradle` içindeki `applicationId` değiştir.

### Icon ve Splash

```bash
npx @capacitor/assets generate --icon --splash
```

`resources/` klasörüne `icon.png` (1024x1024) ve `splash.png` (2732x2732) koy.

### Plugin ekle

```bash
npm install @capacitor/camera
npx cap sync
```

`MainActivity.java`'ya:
```java
registerPlugin(CameraPlugin.class);
```

## 🔧 Sorun Giderme

### "SDK location not found"

`android/local.properties`:
```
sdk.dir=/home/KULLANICI/Android/Sdk
```

### Gradle sync hatası

```bash
cd android
./gradlew --refresh-dependencies
```

### Memory error

`android/gradle.properties`:
```
org.gradle.jvmargs=-Xmx4096m
```

## 📦 Play Store'a Yükleme

1. Release APK (imzalı) üret
2. [Google Play Console](https://play.google.com/console)'a giriş
3. "Uygulama oluştur" → APK yükle
4. Store listing doldur
5. İncelemeye gönder

---

**DeepSeek App Studio** · 1.0.0 · Capacitor 6 · Android 6.0+
