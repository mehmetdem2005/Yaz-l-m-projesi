/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',  // static HTML üret
  images: {
    unoptimized: true,  // Android WebView için
  },
  // Capacitor için asset prefix
  // assetPrefix: './',
  trailingSlash: true,
};

module.exports = nextConfig;
