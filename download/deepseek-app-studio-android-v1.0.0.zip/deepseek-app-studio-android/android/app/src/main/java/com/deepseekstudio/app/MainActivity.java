package com.deepseekstudio.app;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;
import com.getcapacitor.Plugin;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Capacitor plugin'leri buraya eklenebilir
        // registerPlugin(MyPlugin.class);
    }
}
